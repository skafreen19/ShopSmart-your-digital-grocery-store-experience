const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Route (Test)
app.get('/', (req, res) => {
  res.send('ShopSmart API Running');
});

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/shopsmart', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('✅ MongoDB Connected');
  // Start Server Only After Mongo Connects
  app.listen(5000, () => {
    console.log('🚀 Server started at http://localhost:5000');
  });
})
.catch((err) => {
  console.error('❌ MongoDB Connection Failed:', err.message);
});